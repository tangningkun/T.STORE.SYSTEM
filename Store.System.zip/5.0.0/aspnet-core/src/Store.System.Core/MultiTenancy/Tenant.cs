﻿using Abp.MultiTenancy;
using Store.System.Authorization.Users;

namespace Store.System.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
