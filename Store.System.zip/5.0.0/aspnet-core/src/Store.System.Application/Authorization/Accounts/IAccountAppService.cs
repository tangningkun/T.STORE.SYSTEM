﻿using System.Threading.Tasks;
using Abp.Application.Services;
using Store.System.Authorization.Accounts.Dto;

namespace Store.System.Authorization.Accounts
{
    public interface IAccountAppService : IApplicationService
    {
        Task<IsTenantAvailableOutput> IsTenantAvailable(IsTenantAvailableInput input);

        Task<RegisterOutput> Register(RegisterInput input);
    }
}
