﻿using Abp.Application.Services.Dto;

namespace Store.System.Roles.Dto
{
    public class PagedRoleResultRequestDto : PagedResultRequestDto
    {
        public string Keyword { get; set; }
    }
}

