import { setSessionStore, getSessionStore, setCookie } from '@/utils/common-ts/globalFn';
import { ActionTree, MutationTree } from 'vuex';

const state = {
  token: getSessionStore('token'),
};

const mutations: MutationTree<any> = {
  SET_TOKEN(state: any, data: any): void {
    debugger;
    state.token = data;
  },
};

const actions: ActionTree<any, any> = {
  setToken({ commit, state }, data: any) {
    debugger;
    return new Promise((resolve, reject) => {
      commit('SET_TOKEN', data);
      // 将数据存到session缓存与cookie缓存
      setSessionStore('token', data);
      setCookie('token', data);
      // console.log(_getCookie('Token'));
      resolve();
    });
  },
  /**
   * 深拷贝
   * @param param0
   * @param params
   */
  async deep({ state, commit }, params: any) {
    let obj = {};
    obj = JSON.parse(JSON.stringify(params));
    return obj;
  },

  loginOut({ state, commit, dispatch }) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        sessionStorage.clear();
        resolve();
      }, 500);
      setTimeout('location.reload();', 1000); // 延迟1s刷新页面
      /**
       * 将缓存信息清空
       */
      sessionStorage.clear();
      commit('SET_TOKEN', '');
      resolve();
    });
  },
};
export default {
  namespaced: true, // 配合module使用
  actions,
  mutations,
};
