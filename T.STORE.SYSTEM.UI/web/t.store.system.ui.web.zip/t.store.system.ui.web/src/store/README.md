## VUEX 外部调用时，导出函数中加入 namespaced: true, // 配合 module 使用

## dispatch：含有异步操作，例如向后台提交数据，写法： this.\$store.dispatch('mutations 方法名',值)

## commit：同步操作，写法：this.\$store.commit('mutations 方法名',值)
