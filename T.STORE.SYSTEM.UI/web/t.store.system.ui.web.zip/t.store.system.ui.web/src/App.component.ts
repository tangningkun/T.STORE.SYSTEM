import { Component, Vue, Model } from 'vue-property-decorator';

@Component({
  name: 'layout',
})
export default class App extends Vue {
  private loading: boolean = false;
  public computed() {
    // computed
  }
  public watch() {
    // watch
  }
  public methods() {
    // methods
  }
}
