import axios from 'axios';
import qs from 'qs';
import store from '@/store/index';
import GlobalFn from '@/utils/common-ts/globalFn';
import { Message, MessageBox } from 'element-ui';

export default class Interceptors {
  public instance: any;

  constructor(public globalFn: GlobalFn) {
    // 创建axios实例
    this.instance = axios.create({
      /*baseURL: 'https://www.apiopen.top', // api的base_url*/
      timeout: 1000 * 12 /*请求超时时间*/,
      withCredentials: false /*允许使用cookie传值给服务器，并要求服务器指定源和Access-Control-Allow-Credentials: true*/,
    });
    // 初始化拦截器
    this.initInterceptors();
  }

  // 为了让http.ts中获取初始化好的axios实例
  public getInterceptors() {
    return this.instance;
  }

  // 初始化拦截器
  public initInterceptors() {
    // 设置post请求头
    this.instance.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
    /**
     * 请求拦截器
     * 每次请求前，如果存在token则在请求头中携带token
     */
    this.instance.interceptors.request.use(
      (config: any) => {
        // 设置请求头
        const token = store.getters.token;
        token && (config.headers.Authorization = this.globalFn.getSessionStore('token'));

        // 对全局参数做过滤，把不存在的参数删除
        if (config.method === 'post') {
          config.data = qs.parse(config.data);
        } else if (config.method === 'get') {
          for (const key in config.params) {
            if (!config.params[key] && config.params[key] !== 0) {
              delete config.params[key];
            }
          }
        }
        this.globalFn.dataTrim(config.data);
        return config;
      },
      (error: any) => {
        // Do something with request error
        Promise.reject(error);
        console.log('error=>', error);
      }
    );

    // 响应拦截器
    this.instance.interceptors.response.use(
      /**
       * 下面的注释为通过在response里，自定义code来标示请求状态
       * 当code返回如下情况则说明权限有问题，登出并返回到登录页
       * 如想通过xmlhttprequest来状态码标识 逻辑可写在下面error中
       * 以下代码均为样例，请结合自生需求加以修改，若不需要，则可删除
       */
      (response: any) => {
        if (response.headers.authorization) {
          localStorage.setItem('id_token', response.headers.authorization);
        } else {
          if (response.data && response.data.token) {
            localStorage.setItem('id_token', response.data.token);
          }
        }

        if (response.status === 200) {
          return Promise.resolve(response.data);
        } else {
          this.globalFn.requestError(response);
          return Promise.reject(response.data);
        }
      },
      // 请求失败
      (error: any) => {
        const { response } = error;
        if (response) {
          // 请求已发出，但是不在2xx的范围
          this.globalFn.requestError(response);
          return Promise.reject(response.data);
        } else {
          // 处理断网的情况
          // eg:请求超时或断网时，更新state的network状态
          // network状态在app.vue中控制着一个全局的断网提示组件的显示隐藏
          // 关于断网组件中的刷新重新获取数据，会在断网组件中说明

          Message({
            showClose: true,
            message: '提示:网络连接异常,请稍后再试!',
            type: 'error',
            duration: 3 * 1000,
          });
        }
      }
    );
  }
}
