<template>
  <div id="app" class="app-wapper">
    <router-view />
  </div>
</template>

<!--TypeScript -->
<script lang="ts">
import App from './App.component';
export default App;
</script>

<!--scss -->
<style src="./App.scss" lang="scss" scoped></style>
