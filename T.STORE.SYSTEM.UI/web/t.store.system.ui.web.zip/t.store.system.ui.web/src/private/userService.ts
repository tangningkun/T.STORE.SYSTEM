import Interceptors from '../http/interceptors';

export default class UserService {
  constructor(public interceptors: Interceptors) {}
  public getPermissions() {
    this.interceptors.
  }
}
