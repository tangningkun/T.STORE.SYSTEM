import Vue from 'vue';
import App from './App.vue';
import router from '@/router/index';
import store from '@/store/index';
import 'babel-polyfill'; // 编译ES6API
import '@/assets/scss/index.scss';
import ElementUI from 'element-ui';

Vue.config.productionTip = false;
Vue.use(ElementUI);

new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount('#app');
