<template>
  <h1>我是Page页面</h1>
</template>
<script lang="ts">
import Page from './page.component';
export default Page;
</script>
