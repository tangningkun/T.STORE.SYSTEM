import { Vue, Component, Watch } from 'vue-property-decorator';

@Component({
  name: 'page',
})
export default class Page extends Vue {
  private created() {
    console.log('page.created');
  }
  private mounted() {
    console.log('page.mounted');
  }
}
