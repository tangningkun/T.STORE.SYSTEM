<!-- VUE -->
<template>
  <el-container class="layout-main">
    <el-header class="main-container-header">
      <NavHeader></NavHeader>
    </el-header>
    <el-container class="main-container">
      <!-- $store.state.isCollapse ? 'main-aside-false' :  -->
      <el-aside class="main-aside-false">
        <NavTab></NavTab>
      </el-aside>
      <el-main class="main-container-main">
        <div class="main-container-main-header">
          <TagsView></TagsView>
        </div>
        <div class="main-container-main-content">
          <router-view />
        </div>
      </el-main>
    </el-container>
  </el-container>
</template>

<!--TypeScript -->
<script lang="ts">
import Layout from './layout.component';
export default Layout;
</script>

<!--scss -->
<style src="./layout.scss" lang="scss" scoped></style>
