import { Vue, Component, Model, Watch } from 'vue-property-decorator';
import { mapGetters } from 'vuex';
import base from '@/common/style/base.scss';

@Component({
  name: 'tagsView',
  computed: {
    ...mapGetters(['sidebar', 'theme']),
  },
})
export default class TagsView extends Vue {
  private visible: boolean = false;
  private top: number = 0;
  private left: number = 0;
  private selectedTag: any;
  private base: any;
  created() {
    console.log('tagsView.component.created');
  }

  /**
   * 监听路由
   */
  @Watch('$router')
  router() {
    debugger;
    this._addViewTags();
    this._moveToCurrentTag();
  }
  /**
   *
   * @param value 监听左侧菜单栏收缩状态
   */
  @Watch('visible')
  getVisible(value: boolean) {
    debugger;
    if (value) {
      document.body.addEventListener('click', this._closeMenu);
    } else {
      document.body.removeEventListener('click', this._closeMenu);
    }
  }

  public _generateRoute() {
    if (this.$route.name) {
      return this.$route;
    }
    return false;
  }
  public isActive(tag: any) {
    if (tag.path === this.$route.path) {
      return 'background-color: ' + this.base.theme + '; color: #fff;border-color: ' + this.base.theme + ';';
    }
    return false;
  }
  public _addViewTags() {
    const route = this._generateRoute();
    // route || route.path === '/index' || route.path === '/home/index'
    if (!route || route.path === '/retrieve') {
      return false;
    }
    this.$store.dispatch('tagsView/addVisitedViews', route);
  }
  public _moveToCurrentTag() {
    const tags = this.$refs.tag;
    this.$nextTick(() => {
      for (const tag of tags) {
        if (tag.to.path === this.$route.path) {
          if (!tag.$el) break;
          this.$refs.scrollPane.moveToTarget(tag.$el);
          break;
        }
      }
    });
  }
  public _closeSelectedTag(view: any) {
    // 关掉选中的tag后，将最后一个tag变成选择
    this.$store.dispatch('tagsView/delVisitedViews', view).then((views) => {
      if (this.isActive(view)) {
        const latestView = views.slice(-1)[0];
        if (latestView) {
          this.$router.push(latestView);
        } else {
          // 关闭所有路由后进入的页面
          this.$router.push('/');
        }
      }
    });
  }
  public _closeOthersTags() {
    this.$router.push(this.selectedTag);
    this.$store.dispatch('tagsView/delOthersViews', this.selectedTag).then(() => {
      this._moveToCurrentTag();
    });
  }
  public _closeAllTags() {
    this.$store.dispatch('tagsView/delAllViews');
    // 关闭所有路由后进入的页面
    this.$router.push('/');
  }
  public _openMenu(tag: any, e: any) {
    console.log(this);
    this.visible = true;
    this.selectedTag = tag;
    // 不同布局下的位置
    if (!this.$store.getters.sidebar.opened) {
      this.left = e.clientX - 60;
    } else {
      this.left = e.clientX - 220;
    }
    this.top = 40;
  }
  public _closeMenu() {
    this.visible = false;
  }
}
