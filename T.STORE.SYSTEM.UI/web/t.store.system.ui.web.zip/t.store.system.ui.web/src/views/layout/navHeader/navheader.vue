<template> </template>

<!--TypeScript -->
<script lang="ts">
import NavHeader from './navheader.component';
export default NavHeader;
</script>

<style src="./navheader.scss" lang="scss" scoped></style>
