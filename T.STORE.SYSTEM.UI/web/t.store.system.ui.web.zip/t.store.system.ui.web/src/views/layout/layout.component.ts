import { Vue, Component, Model } from 'vue-property-decorator';
import NavHeader from './navHeader/navheader.vue';
import NavTab from './navTab/navtab.vue';
// import TagsView from './tagsView/tagsView.vue';
import { mapGetters } from 'vuex';

@Component({
  name: 'layout',
  components: { NavHeader, NavTab },
  computed: {
    ...mapGetters(['token']),
  },
})
export default class Layout extends Vue {
  private collapsed: boolean = false;
  private created() {
    console.log(this);
    console.log('layout.component.created');
  }
  private handleOpen(key: any, keyPath: any) {
    console.log(key, keyPath);
  }
  private handleClose(key: any, keyPath: any) {
    console.log(key, keyPath);
  }
}
