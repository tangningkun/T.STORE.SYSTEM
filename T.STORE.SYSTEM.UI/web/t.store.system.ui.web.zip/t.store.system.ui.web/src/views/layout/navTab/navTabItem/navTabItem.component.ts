import { Vue, Component, Model } from 'vue-property-decorator';

import { mapGetters } from 'vuex';
@Component({
  name: 'NavTabItem',
  computed: {
    ...mapGetters(['']),
  },
  props: {
    item: {
      type: Object,
      required: true,
    },
  },
})
export default class NavTabItem extends Vue {
  private created() {
    console.log('navTabItem.component.created');
  }

  private resolvePath(item: any) {
    debugger;
    let path = item.path ? item.path + '/' + item.children[0].path : item.children[0].path;
    // let path = item.redirect;
    return path;
  }
  private hasOneShowingChildren(item: any, children: any) {
    debugger;
    // 判断路由是否显示
    let showingChildren = children.filter((item: any) => {
      return !item.hidden;
    });
    // 设置当只有一个子目录的时候并且名字和父级一样时，菜单不展开
    if (showingChildren.length === 1 && showingChildren[0].meta.title === item.meta.title) {
      return true;
    }
    return false;
  }
}
