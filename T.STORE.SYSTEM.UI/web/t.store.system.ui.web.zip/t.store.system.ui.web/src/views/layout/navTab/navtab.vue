<template>
  <el-menu :default-active="$route.path" :collapse="collapsed" class="el-menu-vertical-demo" mode="vertical" unique-opened>
    <NavTabItem v-for="(route, index) in menu" :key="index" :item="route"></NavTabItem>
  </el-menu>
</template>

<script lang="ts">
import NavTab from './navtab.component';
export default NavTab;
</script>

<style src="./navtab.scss" lang="scss" scoped></style>
