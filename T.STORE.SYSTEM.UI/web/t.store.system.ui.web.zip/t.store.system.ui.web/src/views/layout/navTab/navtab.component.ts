import { Vue, Component, Model } from 'vue-property-decorator';
import NavTabItem from './navTabItem/navTabItem.vue';
import bus from '../../../utils/common-ts/bus';
import { mapGetters } from 'vuex';

@Component({
  name: 'navtab',
  computed: {
    ...mapGetters(['menu']),
  },
  components: { NavTabItem },
})
export default class NavTab extends Vue {
  private collapsed: boolean = false;
  private created() {
    let _this = this;
    console.log('navtab.component.created');
    // 通过 Event Bus 进行组件间通信，来折叠侧边栏
    bus.$on('collapse', (msg: any) => {
      _this.collapsed = msg;
    });
  }
}
