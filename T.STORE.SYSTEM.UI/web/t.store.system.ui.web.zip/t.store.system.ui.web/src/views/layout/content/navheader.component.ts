import { Vue, Component } from 'vue-property-decorator';

@Component({
  name: 'navheader',
})
export default class NavHeader extends Vue {
  private activeIndex: any = '1';
  private handleSelect(key: any, keyPath: any) {
    console.log(key, keyPath);
  }
  private goLogout() {
    this.$router.push({ path: '/' });
  }
}
