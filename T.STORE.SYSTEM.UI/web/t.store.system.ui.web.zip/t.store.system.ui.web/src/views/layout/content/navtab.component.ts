import { Vue, Component, Model } from 'vue-property-decorator';

@Component({
  name: 'navtab',
})
export default class NavTab extends Vue {
  private gotoPage(page: any) {
    this.$router.push({ name: page });
  }
}
