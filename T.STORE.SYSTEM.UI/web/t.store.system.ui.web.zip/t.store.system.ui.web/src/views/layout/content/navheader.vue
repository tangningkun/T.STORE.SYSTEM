<template>
  <el-menu :default-active="activeIndex" class="el-menu-demo main-header-el-menu" mode="horizontal" @select="handleSelect">
    <el-submenu index="1" class="main-header-el-menu-item">
      <template slot="title">
        Admin
        <img src="@/assets/img/avatar-1.png" />
      </template>
      <el-menu-item index="2-1">修改密码</el-menu-item>
      <el-menu-item index="2-2">个人信息</el-menu-item>
    </el-submenu>
    <el-menu-item class="main-header-el-menu-item" index="2">
      <el-badge :value="12" class="item">
        <el-button size="small" class="item-el-button">消息</el-button>
      </el-badge>
    </el-menu-item>
    <el-menu-item class="main-header-el-menu-item" index="3" @click="goLogout">
      注销
      <i class="el-icon-switch-button" />
    </el-menu-item>
  </el-menu>
</template>

<!--TypeScript -->
<script lang="ts">
import NavHeader from './navheader.component';
export default NavHeader;
</script>

<style src="./navheader.scss" lang="scss" scoped></style>
