<template>
  <h1>我是首页</h1>
</template>
<script lang="ts">
import Home from './home.component';
export default Home;
</script>

<style src="./home.scss" lang="scss" scoped></style>
