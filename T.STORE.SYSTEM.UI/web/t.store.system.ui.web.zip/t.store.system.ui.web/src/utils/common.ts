/*
 * @Description: 公共函数
 * @Author: asheng
 * @Date: 2018-12-07 11:36:27
 * @LastEditors: asheng
 * @LastEditTime: 2018-12-12 13:37:30
 */

import Cookies from 'js-cookie';
import { cookieExpires } from '@/config'; // cookie保存的天数

/**
 * @param {String} url
 * @description 从URL中解析参数
 */
export const getParams = (url: string) => {
  const keyValueArr = url.split('?')[1].split('&');
  let paramObj: any = {};
  keyValueArr.forEach((item) => {
    const keyValue = item.split('=');
    paramObj[keyValue[0]] = keyValue[1];
  });
  return paramObj;
};

/**
 * 判断一个对象是否存在key，如果传入第二个参数key，则是判断这个obj对象是否存在key这个属性
 * 如果没有传入key这个参数，则判断obj对象是否有键值对
 */
export const hasKey = (obj: any, key: string | number) => {
  if (key) {
    return key in obj;
  } else {
    const keysArr = Object.keys(obj);
    return keysArr.length;
  }
};

/**
 * @msg: 获取系统当前时间
 * @param {string} fmt 时间格式 具体看代码
 * @return: string
 */
export const getDate = (fmt: any) => {
  let time = '';
  const date = new Date();
  const o: any = {
    'M+': date.getMonth() + 1, // 月份
    'd+': date.getDate(), // 日
    'H+': date.getHours(), // 小时
    'm+': date.getMinutes(), // 分
    's+': date.getSeconds(), // 秒
    'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
    'S+': date.getMilliseconds(), // 毫秒
  };
  if (/(y+)/.test(fmt)) {
    time = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
  }
  for (const k in o) {
    if (new RegExp('(' + k + ')').test(fmt)) {
      time = fmt.replace(RegExp.$1, RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
    }
  }
  return time;
};

/**
 * @msg: 获取系统当前时间
 * @param {string} date 时间
 * @param {string} fmt 时间格式
 * @return: string
 */
export const formatDate = (date: any, fmt: string) => {
  let time = '';
  const o: any = {
    'M+': date.getMonth() + 1, // 月份
    'd+': date.getDate(), // 日
    'H+': date.getHours(), // 小时
    'm+': date.getMinutes(), // 分
    's+': date.getSeconds(), // 秒
    'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
    S: date.getMilliseconds(), // 毫秒
  };
  if (/(y+)/.test(fmt)) {
    time = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
  }
  for (const k in o) {
    if (new RegExp('(' + k + ')').test(fmt)) {
      time = fmt.replace(RegExp.$1, RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
    }
  }
  return time;
};

/**
 * 全局去前后空格
 * @param data
 */
export const dataTrim = (data: any) => {
  if (Array.isArray(data)) {
    for (let item of data) {
      if (typeof item === 'object') {
        dataTrim(item);
      } else if (typeof item === 'string') {
        item = item.trim();
      }
    }
  } else if (typeof data === 'object') {
    for (const key in data) {
      if (typeof data[key] === 'object') {
        dataTrim(data[key]);
      } else if (typeof data[key] === 'string') {
        data[key] = data[key].trim();
      }
    }
  }
};
/*----------------------COOKIE与SESSION操作---------------------------------------*/

/**
 * 对cookie操作(赋值)
 * @param key
 * @param value
 * @param params
 * @param type
 */
export const setCookie = (key: any, value: any, params?: any, type?: any) => {
  if (!key) return;
  if (type === 'JSONStr') {
    value = JSON.stringify(value);
  }
  Cookies.set(key, value, params);
};
/**
 * 对cookie操作(取值)
 * @param key
 * @param type
 */
export const getCookie = (key: string, type: any) => {
  if (!Cookies.get(key)) {
    return;
  }
  if (type === 'JSONStr') {
    let cookie = Cookies.get(key);
    // 使用String()方法进行转换类型
    return JSON.parse(String(cookie));
  } else {
    return Cookies.get(key);
  }
};
/**
 * 删除cookie
 * @param key
 */
export const removeCookie = (key: any) => {
  return Cookies.remove(key);
};

/**
 * 对session赋值
 * @param key 键
 * @param value 值
 * @param type 类型
 */
export const setSessionStore = (key: any, value: any, type?: any) => {
  if (!key) return;
  if (type === 'JSONStr') {
    value = JSON.stringify(value);
  }
  sessionStorage.setItem(key, value);
};
/**
 * 获取session
 * @param key 键
 * @param value 值
 */
export const getSessionStore = (key: any, type?: any) => {
  if (!sessionStorage.getItem(key)) {
    return;
  }
  if (type === 'JSONStr') {
    return JSON.parse(String(sessionStorage.getItem(key)));
  } else {
    return sessionStorage.getItem(key);
  }
};

/**
 * 删除session
 * @param key
 */
export const removeSessionStore = (key: any) => {
  if (!key) return;
  sessionStorage.removeItem(key);
};

/**
 * 对localStorage赋值
 * @param key 键
 * @param value 值
 * @param type 类型参数可为空，在参数后加'?'
 */
export const setLocalStore = (key: any, value: any, type?: any) => {
  if (!key) return;
  if (type === 'JSONStr') {
    value = JSON.stringify(value);
  }
  localStorage.setItem(key, value);
};
/**
 * 获取localStorage值
 * @param key 键
 * @param type 类型参数可为空，在参数后加'?'
 */
export const getLocalStore = (key: any, type: any) => {
  if (!localStorage.getItem(key)) {
    return;
  }
  if (type === 'JSONStr') {
    return JSON.parse(String(localStorage.getItem(key)));
  } else {
    return localStorage.getItem(key);
  }
};

/**
 * 删除localStorage
 * @param key 键
 */
export const removeLocalStore = (key: any) => {
  if (!key) return;
  localStorage.removeItem(key);
};
/* --------------------------------------- */
