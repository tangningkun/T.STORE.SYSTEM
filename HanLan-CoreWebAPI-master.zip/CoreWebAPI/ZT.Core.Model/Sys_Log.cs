﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZT.Core.Model
{
    /// <summary>
    /// 系统日志
    /// </summary>
    public class Sys_Log:ModelBase
    {
        /// <summary>
        /// 客户端IP
        /// </summary>
        public string ClientIP { get; set; }
        /// <summary>
        /// 日志内容
        /// </summary>
        public string LogContent { get; set; }
        /// <summary>
        /// 日志用户
        /// </summary>
        public string LogUser { get; set; }
        /// <summary>
        /// 错误信息
        /// </summary>
        public string ErrMsg { get; set; }
        /// <summary>
        /// 操作结果
        /// </summary>
        public bool OperateResult { get; set; }

    }
}
