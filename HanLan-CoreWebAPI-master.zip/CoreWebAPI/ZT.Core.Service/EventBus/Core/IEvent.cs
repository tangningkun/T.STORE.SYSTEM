﻿namespace ZT.Core.Service.EventBus
{
    public interface IEvent
    {
    }
}