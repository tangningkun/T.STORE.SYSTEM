﻿using System;

namespace ZT.Core.IService
{
    public interface IServiceBase
    {
    }
}
