﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Text;
using ZT.Core.Dto;
using ZT.Core.Service;

namespace ZT.Core.MiddleWare
{
    public class BaseController:ControllerBase
    {
       

        /// <summary>
        /// 当前请求的客户端IP
        /// </summary>
        public string ClientIP
        {
            get
            {
                HttpContextAccessor context = new HttpContextAccessor();
                var ip = context.HttpContext?.Connection.RemoteIpAddress.ToString();
                if (!string.IsNullOrEmpty(ip) && IsIP(ip))
                {
                    return ip;
                }
                else
                {

                    return "127.0.0.1";
                }
            }
        }
        [NonAction]
        private static bool IsIP(string ip)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(ip, @"^((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(2[0-4]\d|25[0-5]|[01]?\d\d?)$");
        }
        /// <summary>
        /// 服务
        /// </summary>
        public IList<object> Services { get; set; } = new List<object>();
        /// <summary>
        /// 进入系统的用户
        /// </summary>
        public AppUser AppUser { get; set; }


        /// <summary>
        /// 日志内容
        /// </summary>
        public string LogContent { get; set; }
        /// <summary>
        /// 写日志
        /// </summary>
        /// <param name="ex"></param>
        [NonAction]
        public void WriteLog(Exception ex)
        {
            var lg = AppUser == null ? "" : $"【用户名：{AppUser.UserInfo.Login},姓名：{AppUser.UserProfile.RelName}】";
            var msg = "";
            //提取异常信息
            if (ex != null)
            {
                msg += ex.Message;
                while (ex.InnerException != null)
                {
                    ex = ex.InnerException;
                    msg += ex.Message;
                }
            }
            var d = ClientIP;
            if (!string.IsNullOrEmpty(LogContent))
            {
                string content = LogContent;
                var log = new Model.Sys_Log
                {
                    LogContent = content,
                    LogUser = lg,
                    OperateResult = ex == null ? true : false,
                    ErrMsg = msg,
                    //Creator = AppUser.UserInfo.Login,
                    ClientIP=ClientIP,
                };
                ServiceBase obj = Services[0] as ServiceBase;
                var rpsLog = obj.UnitOfWork.Repository<Model.Sys_Log>();
                rpsLog.Insert(log);
                obj.UnitOfWork.Commit();
            }
        }


    }
}
